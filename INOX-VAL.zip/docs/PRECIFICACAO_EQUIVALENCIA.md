# Relatório de Equivalência da Precificação

- Gerado em: 2026-02-09T12:13:18.665Z
- Planilha (XLSX): data/planilha_preco.xlsx
- Modelo: src/domains/precificacao/embedded/planilha.model.json
- Engine: src/domains/precificacao/engine

## Resumo
- Planilhas avaliadas: 15
- Células comparadas: 1352
- Divergências: 0
- Pendências registradas: 0

## Detalhes por planilha

### Banc
- Células comparadas: 123
- Divergências: 0

### LAVATORIO ATUAL
- Células comparadas: 134
- Divergências: 0

### MicLav
- Células comparadas: 79
- Divergências: 0

###  Grelha
- Células comparadas: 156
- Divergências: 0

### Prat
- Células comparadas: 49
- Divergências: 0

### Mesas
- Células comparadas: 133
- Divergências: 0

### Coifa
- Células comparadas: 73
- Divergências: 0

### Chapa-Mat Ø
- Células comparadas: 40
- Divergências: 0

### EstCarroCantoeira
- Células comparadas: 46
- Divergências: 0

### EstCarroTubo
- Células comparadas: 43
- Divergências: 0

### G Corpo
- Células comparadas: 310
- Divergências: 0

### Gab-Arm
- Células comparadas: 83
- Divergências: 0

### Cant
- Células comparadas: 27
- Divergências: 0

### Batente
- Células comparadas: 56
- Divergências: 0

### Planilha1
- Células comparadas: 0
- Divergências: 0
- Observações:
  - Planilha vazia no modelo; validação ignorada.

## Divergências
- Nenhuma divergência encontrada.

## Pendências
- Nenhuma pendência registrada.