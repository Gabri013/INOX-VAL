# Pendências – Módulo de Precificação

- Nenhuma pendência registrada.
