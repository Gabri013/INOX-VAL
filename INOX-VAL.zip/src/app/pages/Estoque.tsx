import { EstoqueSaldos } from '@/domains/estoque';

export default function Estoque() {
  return <EstoqueSaldos />;
}