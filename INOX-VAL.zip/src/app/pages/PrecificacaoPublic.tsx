import PrecificacaoPage from '@/domains/precificacao/pages/Precificacao';

export default function PrecificacaoPublic() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-6xl">
        <PrecificacaoPage />
      </div>
    </div>
  );
}
