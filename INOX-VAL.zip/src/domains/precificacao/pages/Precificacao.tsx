import { PrecificacaoPage } from "../components/PrecificacaoPage";

export default function Precificacao() {
  return <PrecificacaoPage />;
}
