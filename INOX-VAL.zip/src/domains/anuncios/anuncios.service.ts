/**
 * Anuncios Service (Firestore)
 */

import { anunciosService as firestoreAnunciosService } from '@/services/firestore/anuncios.service';

export const anunciosService = firestoreAnunciosService;
