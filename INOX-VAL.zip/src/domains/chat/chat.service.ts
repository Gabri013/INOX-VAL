/**
 * Chat Service (Firestore)
 */

import { chatService as firestoreChatService } from '@/services/firestore/chat.service';

export const chatService = firestoreChatService;
