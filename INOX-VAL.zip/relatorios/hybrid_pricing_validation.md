# Validação da Precificação Híbrida

Gerado em: 2026-02-15T14:31:14.558Z

## Cobertura
- Registros avaliados: **1018**
- Fator de família aplicado: **100%**
- Fator de subfamília aplicado: **85%**
- Dimensão detectada: **87%**
- Complexidade aplicada: **85%**

## Arquivo detalhado
- relatorios/hybrid_pricing_validation.json
