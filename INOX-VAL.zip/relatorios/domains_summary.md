# Domains Summary

| Dominio | Arquivos | Volume MB | OP detectadas |
|---|---:|---:|---:|
| coccao | 218 | 32.70 | 136 |
| compras_orcamentos | 14 | 0.32 | 12 |
| lavacao | 101 | 7.95 | 31 |
| movel_inox | 359 | 21.29 | 258 |
| outros | 1053 | 136.88 | 347 |
| refrigeracao | 240 | 24.69 | 149 |

Regras de dominio usadas no processamento: `domain_rules.json`.